﻿namespace Bct.SearchFight.Core.Models
{
    public class Search
    {
        public string SearchEngine { get; set; }
        public string Term { get; set; }
        public long Results { get; set; }       
    }
}
