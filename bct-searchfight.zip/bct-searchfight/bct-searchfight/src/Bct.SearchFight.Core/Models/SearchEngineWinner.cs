﻿namespace Bct.SearchFight.Core.Models
{
    public class SearchEngineWinner
    {
        public string Engine { get; set; }
        public string Term { get; set; }
    }
}
