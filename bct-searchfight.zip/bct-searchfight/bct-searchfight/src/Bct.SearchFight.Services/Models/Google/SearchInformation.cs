﻿namespace Bct.SearchFight.Services.Models

{
    public class SearchInformation
    {
        public string TotalResults { get; set; }
    }
}
