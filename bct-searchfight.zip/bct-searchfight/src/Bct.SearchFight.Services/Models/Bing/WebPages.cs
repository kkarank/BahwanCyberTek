﻿namespace Bct.SearchFight.Services.Models

{
    public class WebPages
    {
        public string TotalEstimatedMatches { get; set; }
    }
}
