﻿namespace Bct.SearchFight.Services.Models

{
    public class GoogleResponse
    {
        public SearchInformation SearchInformation { get; set; }
    }
}